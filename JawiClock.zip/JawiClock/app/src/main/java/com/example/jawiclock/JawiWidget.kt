package com.example.jawiclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.TypedValue
import android.widget.RemoteViews
import java.util.Calendar

class JawiWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        updateAll(ctx)
        schedule(ctx)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        ids.forEach { Prefs.delete(ctx, it) }
    }

    override fun onEnabled(ctx: Context) = schedule(ctx)

    override fun onDisabled(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pendingTick(ctx))
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_TICK,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                updateAll(ctx)
                schedule(ctx)
            }
        }
    }

    companion object {
        private const val ACTION_TICK = "com.example.jawiclock.TICK"

        /** Bina paparan widget ikut gaya. Dipakai juga untuk pratonton dalam ConfigActivity. */
        fun build(ctx: Context, id: Int, st: Style, now: Calendar = Calendar.getInstance()): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_jawi)
            rv.setTextViewText(R.id.time, Jawi.time(now))
            rv.setTextViewText(R.id.period, Jawi.period(now))
            rv.setTextViewText(R.id.date, Jawi.date(now))

            val k = st.scale / 100f
            rv.setTextViewTextSize(R.id.bismillah, TypedValue.COMPLEX_UNIT_SP, 20f * k)
            rv.setTextViewTextSize(R.id.time, TypedValue.COMPLEX_UNIT_SP, 48f * k)
            rv.setTextViewTextSize(R.id.period, TypedValue.COMPLEX_UNIT_SP, 20f * k)
            rv.setTextViewTextSize(R.id.date, TypedValue.COMPLEX_UNIT_SP, 15f * k)

            rv.setTextColor(R.id.time, st.text)
            rv.setTextColor(R.id.date, st.text)
            rv.setTextColor(R.id.bismillah, st.accent)
            rv.setTextColor(R.id.period, st.accent)

            rv.setInt(R.id.bg, "setColorFilter", st.bg)
            rv.setFloat(R.id.bg, "setAlpha", st.bgAlpha / 100f)

            // Tekan widget = buka tetapan warna & saiz
            val cfg = Intent(ctx, ConfigActivity::class.java)
                .setAction(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(
                ctx, id, cfg,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            rv.setOnClickPendingIntent(R.id.root, pi)
            return rv
        }

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, JawiWidget::class.java))
            val now = Calendar.getInstance()
            for (id in ids) {
                mgr.updateAppWidget(id, build(ctx, id, Prefs.load(ctx, id), now))
            }
        }

        private fun pendingTick(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ctx, JawiWidget::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        // Kejutkan widget pada permulaan setiap minit
        fun schedule(ctx: Context) {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val next = Calendar.getInstance().apply {
                add(Calendar.MINUTE, 1)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val pi = pendingTick(ctx)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
                }
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
            }
        }
    }
}
